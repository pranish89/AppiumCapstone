package oopsConcepts.Jonah;

public class Animal {

public String Famil="Animal";

 public Animal() {
	 System.out.println("This is Animal CLass Constructor");
	
	}

}
