package oopsConcepts.Jonah;

public class Fish extends Animal{
	
	String habitat,type;

	public Fish() {
		System.out.println("This is fish class constructor");

	}
}
