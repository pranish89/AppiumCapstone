package oopsConcepts.Jonah;

public class Shark extends Fish {
	
	String kind;
	
	
	public Shark()
	{
		System.out.println("This is shark class constructor");
		//initializing all the parent class variable here
		habitat="Water";
		type="Aquatic";
		kind="Shark";
	}
		

}
