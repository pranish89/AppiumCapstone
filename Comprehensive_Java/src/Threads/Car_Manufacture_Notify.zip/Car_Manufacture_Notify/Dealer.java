package Threads.Car_Manufacture_Notify;

public class Dealer {
	

	public void purchaseCars() {
		
     System.out.println("Dealer: Order received from Manager.Purchasing and marketing cars to the customers...");
		
		
		System.out.println("Dealer: Cars delivered to the customers successfully!");
				
	}

}
