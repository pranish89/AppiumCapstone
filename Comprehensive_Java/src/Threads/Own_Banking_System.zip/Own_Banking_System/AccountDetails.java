package Threads.Own_Banking_System;

public class AccountDetails {

	public void details() {
		
		System.out.println("Account details are displayed");
	}

}
