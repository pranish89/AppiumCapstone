package Threads.Own_Banking_System;

public class AccountMain {

	public static void main(String[] args) {
		
		WelcomePage welcome = new WelcomePage();
		welcome.start();

	}

}
