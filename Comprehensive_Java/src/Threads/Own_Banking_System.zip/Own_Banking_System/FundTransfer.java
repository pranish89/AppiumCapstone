package Threads.Own_Banking_System;

public class FundTransfer {

	public void transfer() {
		
		System.out.println("Enter the amount and account details ");
		System.out.println("The funds are transfered");
		
	}

}
