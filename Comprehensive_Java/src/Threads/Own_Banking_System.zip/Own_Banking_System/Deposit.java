package Threads.Own_Banking_System;

public class Deposit {

	public void depositfunds() {

		System.out.println("Enter the deposit amount:");
		
		System.out.println("The amount is deposited");
	}

}
