package Threads.Own_Banking_System;

public class Withdraw {

	public void withdrafunds() {
		
		System.out.println("Enter the withdrawal amount");
		System.out.println("The amount is withdrawn and balance is displayed.");
		
	}

}
