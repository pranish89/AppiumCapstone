package exception;

public class BankOwnException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public BankOwnException(String msg) {
		super(msg);
	}

}
