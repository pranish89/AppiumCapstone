package interfaces_enums;

public interface Vehicle {
	
	
	public void setter(String a, double b,double c);
	
	
	public void getter();
	

}
